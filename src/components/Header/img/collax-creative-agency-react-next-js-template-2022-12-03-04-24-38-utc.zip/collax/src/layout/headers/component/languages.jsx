import React from 'react';

const Languages = () => {
  return (
    <ul>
      <li><a href="#">English</a></li>
      <li><a href="#">Arabic</a></li>
      <li><a href="#">Spanish</a></li>
    </ul>
  );
};

export default Languages;