const firebaseConfig = {
  apiKey: "AIzaSyC6q63VgF5ikfKJCDajmC-aFvzpEh6dBJU",
  authDomain: "collax-cf6be.firebaseapp.com",
  projectId: "collax-cf6be",
  storageBucket: "collax-cf6be.appspot.com",
  messagingSenderId: "266530521253",
  appId: "1:266530521253:web:95c0f3fe64f27eedb20d4c"
};

export default firebaseConfig;