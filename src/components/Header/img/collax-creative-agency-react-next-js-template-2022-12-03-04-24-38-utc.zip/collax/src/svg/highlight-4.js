import React from 'react';

const HighlightFour = () => {
  return (
    <svg width="91" height="12" viewBox="0 0 91 12" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M0 0L91 12H0V0Z" fill="#82CEFD" />
    </svg>
  );
};

export default HighlightFour;