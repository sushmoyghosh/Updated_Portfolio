import React from 'react';

const IntroduceArea = () => {
  return (
    <div className="cd-introduce-area pb-80 ">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="cd-info-box">
              <h3 className="tp-title-sm pb-30">Introducing Shine: the way to live mindfully</h3>
              <p className="mb-25">One in four people in the world will be affected by mental or neurological disorders at some point in their lives, says the World Health Organization. Still, we spend more time brushing our teeth than taking care of our mental health, said Guy Winch in his TED talk.
              </p>
              <p className="mb-25">We tend to neglect our mental well-being because of the stigma of mental health care. But as societies become wiser and more self-aware, there is a greater need to redefine the meaning of mental health care. Naomi Hirabayashi and Marah Lidey do exactly that by drawing attention to the aspect of preventing mental health issues. The application they built makes mental self-care easy and accessible. of this year of the best law and his a part of this years.</p>
              <p>We tend to neglect our mental well-being because of the stigma of mental health care. But as societies become wiser and more self-aware, there is a greater need to redefine the meaning of mental health care. Naomi Hirabayashi and Marah Lidey do exactly that by drawing attention to the aspect of preventing mental health issues. The application they built makes mental self-care easy and accessible. of this year of the best law and his a part of this years.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntroduceArea;