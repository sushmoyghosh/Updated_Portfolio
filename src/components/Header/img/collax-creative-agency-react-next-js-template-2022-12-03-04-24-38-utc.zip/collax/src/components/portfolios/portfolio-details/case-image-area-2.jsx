import React from 'react';

const CaseImageAreaTwo = () => {
  return (
    <div className="cd-banner-area pb-100">
      <div className="container">
        <div className="row">
          <div className="col-12">
            <div className="cd-banner-img">
              <img src="/assets/img/case/case-2.jpg" alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaseImageAreaTwo;